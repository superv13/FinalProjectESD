This repository contains the backend code for the ESD Miniproject. The front end is in the repo https://github.com/aishwarya-panampilly/esd-mini-frontend<br>
To run the application, open in IntelliJ and run<br>
To run SQL Scripts, go to mySQL Command Line and type<br>
use database ESDFinal<br>
source (path of file)<br>
Execute in order create,alter,insert<br>

<h1>Functionality</h1>
<h3>3.2 Faculty Details Modify</h3>
Modify all details of the faculty including employee id, photograph(do not save as blob) and courses (Drop Down Selection), accordingly update all referenced tables.
