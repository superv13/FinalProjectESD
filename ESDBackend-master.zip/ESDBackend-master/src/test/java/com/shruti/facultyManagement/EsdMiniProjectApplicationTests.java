package com.shruti.facultyManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsdMiniProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
