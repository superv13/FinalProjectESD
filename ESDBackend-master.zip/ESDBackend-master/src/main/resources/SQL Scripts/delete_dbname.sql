#only for testing purposes
DROP TABLE IF EXISTS Courses;
DROP TABLE IF EXISTS Faculty_courses;
DROP TABLE IF EXISTS Departments;
DROP TABLE IF EXISTS Employee_salary;
DROP TABLE IF EXISTS Employees;
